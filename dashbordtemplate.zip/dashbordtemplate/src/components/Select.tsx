"use client"

import type React from "react"

import { useState } from "react"

interface SelectProps {
  defaultValue?: string
  onValueChange?: (value: string) => void
  children: React.ReactNode
  className?: string
}

interface SelectItemProps {
  value: string
  children: React.ReactNode
}

export function Select({ defaultValue, onValueChange, children, className = "" }: SelectProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedValue, setSelectedValue] = useState(defaultValue || "")

  const handleSelect = (value: string) => {
    setSelectedValue(value)
    onValueChange?.(value)
    setIsOpen(false)
  }

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-3 py-2 text-left bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
      >
        {selectedValue || "Select..."}
        <span className="absolute inset-y-0 right-0 flex items-center pr-2">▼</span>
      </button>

      {isOpen && (
        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg">{children}</div>
      )}
    </div>
  )
}

export function SelectItem({ value, children }: SelectItemProps) {
  return (
    <div onClick={() => {}} className="px-3 py-2 cursor-pointer hover:bg-gray-100" data-value={value}>
      {children}
    </div>
  )
}
