"use client"

import { useState } from "react"
import { Button } from "../components/Button"
import { Card, CardContent, CardHeader, CardTitle } from "../components/Card"
import { Badge } from "../components/Badge"

// Simple icon components
const MenuIcon = () => <span>☰</span>
const StarIcon = () => <span>⭐</span>
const DownloadIcon = () => <span>⬇</span>
const MailIcon = () => <span>✉</span>
const ShoppingCartIcon = () => <span>🛒</span>
const HomeIcon = () => <span>🏠</span>
const LayoutIcon = () => <span>📋</span>
const FileTextIcon = () => <span>📄</span>
const GridIcon = () => <span>⊞</span>
const PlusIcon = () => <span>➕</span>
const MapIcon = () => <span>🗺</span>
const ChartIcon = () => <span>📊</span>
const ChevronLeftIcon = () => <span>‹</span>
const ChevronRightIcon = () => <span>›</span>
const ChevronDownIcon = () => <span>▼</span>
const SettingsIcon = () => <span>⚙</span>
const TrendingUpIcon = () => <span>📈</span>
const TrendingDownIcon = () => <span>📉</span>
const EditIcon = () => <span>✏</span>
const BriefcaseIcon = () => <span>💼</span>

export default function Dashboard() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-purple-600 text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            className="text-white hover:bg-purple-700"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            <MenuIcon />
          </Button>
          <h1 className="text-xl font-semibold">ngx-admin</h1>
          <div className="w-40">
            <select className="w-full px-3 py-1 text-black rounded">
              <option>Material Light</option>
              <option>Material Dark</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <StarIcon />
            <span>Star</span>
            <Badge variant="secondary" className="bg-white text-black">
              25,494
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <DownloadIcon />
            <span>470,000</span>
          </div>
          <div className="flex items-center gap-2">
            <MailIcon />
            <span>CONTACT@AKVEO.COM</span>
          </div>
          <div className="flex items-center gap-2">
            <img
              src="/placeholder.svg?height=32&width=32"
              alt="Nick Jones"
              className="w-8 h-8 rounded-full bg-gray-300"
            />
            <span>Nick Jones</span>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`bg-white shadow-sm transition-all duration-300 ${sidebarCollapsed ? "w-16" : "w-64"}`}>
          <nav className="p-4 space-y-2">
            <div className="flex items-center gap-3 p-2 text-purple-600 bg-purple-50 rounded">
              <ShoppingCartIcon />
              {!sidebarCollapsed && <span className="text-sm font-medium">E-commerce</span>}
            </div>

            <div className="flex items-center gap-3 p-2 text-gray-600 hover:bg-gray-50 rounded cursor-pointer">
              <HomeIcon />
              {!sidebarCollapsed && <span className="text-sm">IoT Dashboard</span>}
            </div>

            {!sidebarCollapsed && (
              <>
                <div className="pt-4 pb-2">
                  <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">FEATURES</h3>
                </div>

                <div className="space-y-1">
                  {[
                    { icon: <LayoutIcon />, label: "Layout" },
                    { icon: <FileTextIcon />, label: "Forms" },
                    { icon: <GridIcon />, label: "UI Features" },
                    { icon: <GridIcon />, label: "Modal & Overlays" },
                    { icon: <PlusIcon />, label: "Extra Components" },
                    { icon: <MapIcon />, label: "Maps" },
                    { icon: <ChartIcon />, label: "Charts" },
                  ].map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 text-gray-600 hover:bg-gray-50 rounded cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        {item.icon}
                        <span className="text-sm">{item.label}</span>
                      </div>
                      <ChevronLeftIcon />
                    </div>
                  ))}
                </div>
              </>
            )}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Top Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-purple-600 rounded flex items-center justify-center text-white text-2xl">
                    <EditIcon />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">Hire us to customize</h3>
                    <p className="text-gray-600 text-sm">ngx-admin</p>
                  </div>
                  <Button>CONTACT US</Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-purple-600 rounded flex items-center justify-center text-white text-2xl">
                    <BriefcaseIcon />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">Documentation and</h3>
                    <p className="text-gray-600 text-sm">customization articles</p>
                  </div>
                  <Button>LEARN MORE</Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Profit Chart */}
            <Card>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <span>$</span>
                    <span>Profit</span>
                  </CardTitle>
                  <ChevronRightIcon />
                </div>
                <div className="flex items-center gap-4 mt-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
                    <span className="text-sm text-gray-600">transactions</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-600">orders</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-48 flex items-end justify-between gap-1">
                  {Array.from({ length: 30 }, (_, i) => (
                    <div key={i} className="flex flex-col gap-1 flex-1">
                      <div className="bg-green-500 rounded-sm" style={{ height: `${Math.random() * 80 + 20}%` }}></div>
                      <div className="bg-purple-600 rounded-sm" style={{ height: `${Math.random() * 60 + 10}%` }}></div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Bitcoin Card */}
            <Card>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">Bitcoin</span>
                    <ChevronDownIcon />
                  </div>
                  <ChevronRightIcon />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Daily Income</p>
                      <p className="text-2xl font-bold">45,895</p>
                    </div>
                    <div className="flex items-center gap-1 text-green-600">
                      <TrendingUpIcon />
                      <span className="text-sm font-medium">4%</span>
                    </div>
                    <SettingsIcon />
                  </div>
                  <div className="h-32 bg-purple-600 rounded"></div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Traffic Section */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Traffic</CardTitle>
                <div className="flex items-center gap-2">
                  <select className="px-2 py-1 border rounded">
                    <option>week</option>
                    <option>month</option>
                  </select>
                  <ChevronRightIcon />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between py-4">
                <div className="flex items-center gap-4">
                  <span className="text-gray-600">Mon</span>
                  <span className="font-semibold">932</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 text-red-600">
                    <TrendingDownIcon />
                    <span className="text-sm">12%</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>Sun</span>
                    <div className="w-8 h-1 bg-red-500 rounded"></div>
                    <span>Mon</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
